---
description: Abrir Compendia Bibliotheca (descobre os autores da sua chave)
---
Chame `listar_autores` do conector compendia, saúde com o nome do acervo e os autores, e então: $ARGUMENTS
