Compendia Bibliotheca — este plugin é só o gatilho: não há texto de persona nem chave aqui dentro. Na primeira consulta ele pede para você entrar; a partir daí a voz, os autores e o acervo chegam pelo servidor, conforme a sua licença. Autor novo no acervo aparece sozinho, sem reinstalar nada.

Suporte: contato@compendia.com.br · https://compendia.com.br
